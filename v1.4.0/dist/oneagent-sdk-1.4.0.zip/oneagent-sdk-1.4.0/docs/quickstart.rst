Quickstart
==========

The following example shows most features of the Python SDK:

.. literalinclude:: ../samples/basic-sdk-sample/basic_sdk_sample.py

See the rest of the documentation and the `README on GitHub
<https://github.com/Dynatrace/OneAgent-SDK-for-Python/blob/master/README.md#readme>`_
for more information.

Welcome to the documentation for Dynatrace OneAgent SDK for Python
==================================================================

If you are new to the Dynatrace OneAgent SDK for Python, please consult the
`README on GitHub
<https://github.com/Dynatrace/OneAgent-SDK-for-Python/blob/master/README.md#readme>`_.
It also contains installation instructions.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   sdkref
   encoding
   tagging



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

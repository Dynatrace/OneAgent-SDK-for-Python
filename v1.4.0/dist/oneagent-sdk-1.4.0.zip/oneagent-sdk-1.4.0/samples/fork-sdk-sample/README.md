# OneAgent SDK for Python forking sample

This example demonstrates how to use the [OneAgent SDK for
Python](https://github.com/Dynatrace/OneAgent-SDK-for-Python) with forked child processes.
